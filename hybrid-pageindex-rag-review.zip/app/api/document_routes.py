from datetime import datetime, timezone
from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.database.database import get_db
from app.models.document import Document
from app.schemas.document import DocumentCreate, DocumentResponse


router = APIRouter(
    prefix="/documents",
    tags=["Documents"],
)


@router.post("/", response_model=DocumentResponse)
def create_document(
    document_data: DocumentCreate,
    db: Session = Depends(get_db),
):
    document = Document(
        owner_id=document_data.owner_id,
        title=document_data.title,
        original_filename=document_data.original_filename,
        mime_type=document_data.mime_type,
        file_extension=document_data.file_extension,
        file_size_bytes=document_data.file_size_bytes,
        storage_path=document_data.storage_path,
        file_checksum=document_data.file_checksum,

        raw_text=document_data.raw_text,
        parsed_json=document_data.parsed_json,
        okf_markdown=document_data.okf_markdown,
        okf_metadata=document_data.okf_metadata,

        status=document_data.status,
        parse_status=document_data.parse_status,
        index_status=document_data.index_status,
        okf_status=document_data.okf_status,

        error_message=document_data.error_message,
        version=document_data.version,
        is_active=document_data.is_active,

        llm_config_id=document_data.llm_config_id,
        created_by=document_data.created_by,
        updated_by=document_data.updated_by,
    )

    db.add(document)
    db.commit()
    db.refresh(document)

    return document


@router.get("/", response_model=list[DocumentResponse])
def list_documents(
    db: Session = Depends(get_db),
):
    return (
        db.query(Document)
        .filter(Document.deleted_at.is_(None))
        .order_by(Document.created_at.desc())
        .all()
    )


@router.get("/{document_id}", response_model=DocumentResponse)
def get_document(
    document_id: UUID,
    db: Session = Depends(get_db),
):
    document = (
        db.query(Document)
        .filter(
            Document.id == document_id,
            Document.deleted_at.is_(None),
        )
        .first()
    )

    if not document:
        raise HTTPException(
            status_code=404,
            detail="Document not found",
        )

    return document


@router.put("/{document_id}", response_model=DocumentResponse)
def update_document(
    document_id: UUID,
    document_data: DocumentCreate,
    db: Session = Depends(get_db),
):
    document = (
        db.query(Document)
        .filter(
            Document.id == document_id,
            Document.deleted_at.is_(None),
        )
        .first()
    )

    if not document:
        raise HTTPException(
            status_code=404,
            detail="Document not found",
        )

    document.owner_id = document_data.owner_id
    document.title = document_data.title
    document.original_filename = document_data.original_filename
    document.mime_type = document_data.mime_type
    document.file_extension = document_data.file_extension
    document.file_size_bytes = document_data.file_size_bytes
    document.storage_path = document_data.storage_path
    document.file_checksum = document_data.file_checksum

    document.raw_text = document_data.raw_text
    document.parsed_json = document_data.parsed_json
    document.okf_markdown = document_data.okf_markdown
    document.okf_metadata = document_data.okf_metadata

    document.status = document_data.status
    document.parse_status = document_data.parse_status
    document.index_status = document_data.index_status
    document.okf_status = document_data.okf_status

    document.error_message = document_data.error_message
    document.version = document_data.version
    document.is_active = document_data.is_active

    document.llm_config_id = document_data.llm_config_id
    document.created_by = document_data.created_by
    document.updated_by = document_data.updated_by

    document.updated_at = datetime.now(timezone.utc)

    db.commit()
    db.refresh(document)

    return document


@router.delete("/{document_id}")
def delete_document(
    document_id: UUID,
    db: Session = Depends(get_db),
):
    document = (
        db.query(Document)
        .filter(
            Document.id == document_id,
            Document.deleted_at.is_(None),
        )
        .first()
    )

    if not document:
        raise HTTPException(
            status_code=404,
            detail="Document not found",
        )

    document.deleted_at = datetime.now(timezone.utc)
    document.updated_at = datetime.now(timezone.utc)

    db.commit()

    return {
        "message": "Document deleted successfully",
        "document_id": document_id,
    }